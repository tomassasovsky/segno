%TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*%
%TF.CreationDate,2026-07-19T05:34:46-03:00*%
%TF.ProjectId,loopy_led_strip,6c6f6f70-795f-46c6-9564-5f7374726970,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-07-19 05:34:46*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.090000X-0.660000X-0.360000X0.660000X-0.360000X0.660000X0.360000X-0.660000X0.360000X0*%
%ADD11RoundRect,0.225000X0.250000X-0.225000X0.250000X0.225000X-0.250000X0.225000X-0.250000X-0.225000X0*%
%ADD12C,1.600000*%
G04 APERTURE END LIST*
D10*
%TO.C,D1*%
X55550000Y-52350000D03*
X55550000Y-55650000D03*
X60450000Y-55650000D03*
X60450000Y-52350000D03*
%TD*%
D11*
%TO.C,C1*%
X53800000Y-54775000D03*
X53800000Y-53225000D03*
%TD*%
D12*
%TO.C,J2*%
X66000000Y-51500000D03*
X66000000Y-54000000D03*
X66000000Y-56500000D03*
%TD*%
%TO.C,J1*%
X50000000Y-51500000D03*
X50000000Y-54000000D03*
X50000000Y-56500000D03*
%TD*%
M02*
